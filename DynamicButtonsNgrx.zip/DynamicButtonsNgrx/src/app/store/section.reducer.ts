// import { createReducer, on } from '@ngrx/store';
// import { setCurrentSection, addButtonData, resetSections } from './section.actions';

// // Define the initial state
// export interface SectionState {
//   [x: string]: any;
//   currentSection: string | null;
//   sectionData: { [key: string]: { name: string; value: number }[] };
//   totalValue: number;
// }

// export const initialState: SectionState = {
//   currentSection: null,
//   sectionData: {},
//   totalValue: 0,
// };

// // Define the reducer
// export const sectionReducer = createReducer(
//   initialState,
//   on(setCurrentSection, (state, { section }) => ({
//     ...state,
//     currentSection: section,
//   })),
//   on(addButtonData, (state, { section, name, value }) => {
//     const newSectionData = {
//       ...state.sectionData,
//       [section]: state.sectionData[section] ? [...state.sectionData[section], { name, value }] : [{ name, value }],
//     };
//     const newTotalValue = Object.values(newSectionData)
//       .flat()
//       .reduce((total, item) => total + item.value, 0);
//     return {
//       ...state,
//       sectionData: newSectionData,
//       totalValue: newTotalValue,
//     };
//   }),
//   on(resetSections, (state) => ({
//     ...state,
//     sectionData: {},
//     totalValue: 0,
//     currentSection: null,
//   }))
// );
import { createReducer, on } from '@ngrx/store';
import { setCurrentSection, addButtonData, resetSections } from './section.actions';

// Define the initial state
export interface SectionState {
  currentSection: string | null;
  sectionData: { [key: string]: { name: string; value: number } | null };
  totalValue: number;
}

export const initialState: SectionState = {
  currentSection: null,
  sectionData: {},
  totalValue: 0,
};

// Define the reducer
export const sectionReducer = createReducer(
  initialState,
  on(setCurrentSection, (state, { section }) => ({
    ...state,
    currentSection: section,
  })),
  on(addButtonData, (state, { section, name, value }) => {
    // Replace any existing selection in the section with the new selection
    const newSectionData = {
      ...state.sectionData,
      [section]: { name, value },
    };

    // Recalculate the total value across all sections
    const newTotalValue = Object.values(newSectionData)
      .filter(item => item !== null) // Filter out null entries
      .reduce((total, item) => total + (item ? item.value : 0), 0);

    return {
      ...state,
      sectionData: newSectionData,
      totalValue: newTotalValue,
    };
  }),
  on(resetSections, (state) => ({
    ...state,
    sectionData: {},
    totalValue: 0,
    currentSection: null,
  }))
);
