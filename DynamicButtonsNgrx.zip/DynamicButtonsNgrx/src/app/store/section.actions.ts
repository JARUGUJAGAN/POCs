import { createAction, props } from '@ngrx/store';

// Action for setting the current section
export const setCurrentSection = createAction(
  '[Section] Set Current Section',
  props<{ section: string }>()
);

// Action for adding button data to a section
export const addButtonData = createAction(
  '[Section] Add Button Data',
  props<{ section: string, name: string, value: number }>()
);

// Action for resetting all sections
export const resetSections = createAction('[Section] Reset Sections');
