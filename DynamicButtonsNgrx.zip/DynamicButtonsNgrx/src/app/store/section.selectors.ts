// src/app/store/section.selectors.ts
import { createFeatureSelector, createSelector } from '@ngrx/store';
import { SectionState } from './section.reducer';

export const selectSectionState = createFeatureSelector<SectionState>('section');

export const selectSelectedSection = createSelector(
  selectSectionState,
  (state: SectionState) => state.selectedSection
);

export const selectSectionData = createSelector(
  selectSectionState,
  (state: SectionState) => state.sectionData
);

export const selectTotalValue = createSelector(
  selectSectionState,
  (state: SectionState) => state.totalValue
);
