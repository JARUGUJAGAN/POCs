import { Component, OnInit } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { setCurrentSection, addButtonData, resetSections } from '../store/section.actions';
import { Observable } from 'rxjs';
import { SectionState } from '../store/section.reducer';
import {ChildComponent} from '../child/child.component'
import { CommonModule } from '@angular/common';  // Import CommonModule
@Component({
  selector: 'app-parent',
  standalone: true,
  imports: [ChildComponent,CommonModule],
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css'],
})
export class ParentComponent implements OnInit {
  sections = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10'];
  sectionData$!: Observable<{ [key: string]: { name: string; value: number; }|null; }>;
  totalValue$!: Observable<number>;
  currentSection$!: Observable<string | null>;
  selectedSection!: string | null;
  constructor(private store: Store<{ section: SectionState }>) {}

  ngOnInit() {
    // Subscribe to section data and total value from the store
    this.sectionData$ = this.store.pipe(select((state) => state.section.sectionData));
    this.totalValue$ = this.store.pipe(select((state) => state.section.totalValue));
    this.currentSection$ = this.store.pipe(select((state) => state.section.currentSection));
    this.currentSection$.subscribe((section) => {
      this.selectedSection = section;
    });
  }

  selectSection(section: string) {
    this.store.dispatch(setCurrentSection({ section }));
  }

  addButton(section: string, name: string, value: number) {
    this.store.dispatch(addButtonData({ section, name, value }));
  }

  resetSections() {
    this.store.dispatch(resetSections());
  }
}
