import { Component, OnInit,Input } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';
import { addButtonData } from '../store/section.actions';
import { SectionState } from '../store/section.reducer';
import { CommonModule } from '@angular/common';  // Import CommonModule
@Component({
  selector: 'app-child',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css'],
})
export class ChildComponent implements OnInit {
  currentSection$!: Observable<string | null>;
  buttons$!: Observable<{ name: string; value: number; }[]>;
  @Input() section!: string;
  constructor(private store: Store<{ section: SectionState }>) {}

  ngOnInit() {
    this.currentSection$ = this.store.pipe(select((state) => state.section.currentSection));
    this.buttons$ = this.currentSection$.pipe(
      select((section) => section ? this.getButtonsForSection(section) : [])
    );
  }

  getButtonsForSection(section: string): { name: string; value: number }[] {
    const buttonData: { [key: string]: { name: string; value: number }[] } = {
      "1": [
        { name: '#fgg', value: 2 },
        { name: ' $779', value: 6 }, { name: ' !898989', value: 66 },
        { name: ' &bjbbj', value: 223 },
      ],
      "2": [
        { name: ' ERT66', value: 7 },
        { name: ' @ggugj', value: 3 }, { name: ' !898989', value: 66 },
        { name: ' &bjbbj', value: 223 },
      ],
      "3": [
        { name: ' @55', value: 88 },
        { name: ' !jbjbj', value: 69 },
        { name: ' ERT66', value: 7 },
        { name: ' @ggugj', value: 3 },
      ],
      "4": [
        { name: ' Goooo', value: 99 },
        { name: ' LULUL', value: 77 },{ name: ' &&&777', value: 66 },
        { name: ' 876476', value: 223 },
      ],
      "5": [
        { name: ' *gyfyf', value: 90 },
        { name: ' ^&**#', value: 889 },{ name: ' ERT66', value: 7 },
        { name: ' @ggugj', value: 3 },
      ],
      "6": [
        { name: ' !898989', value: 66 },
        { name: ' &bjbbj', value: 223 }, { name: ' &&&777', value: 66 },
        { name: ' 876476', value: 223 },
      ],
      "7": [
        { name: ' !78797', value: 66 },
        { name: ' ((777(', value: 223 },{ name: ' !898989', value: 66 },
        { name: ' &bjbbj', value: 223 },
      ],
      "8": [
        { name: ' )(*&^%', value: 66 },
        { name: ' )(@@!', value: 223 },{ name: ' !898989', value: 66 },
        { name: ' &bjbbj', value: 223 },
      ],
      "9": [
        { name: ' &&&777', value: 66 },
        { name: ' 876476', value: 223 }, { name: ' @55', value: 88 },
        { name: ' !jbjbj', value: 69 },
        { name: ' ERT66', value: 7 },
        { name: ' @ggugj', value: 3 },
      ],"10": [
        { name: ' ^^^^^^', value: 66 },
        { name: ' *(*&^*', value: 223 }, { name: ' &&&777', value: 66 },
        { name: ' 876476', value: 223 },
      ]
      // Add more sections as needed
    };
    return buttonData[section] || [];
  }

  onButtonClick(section:string,name: string, value: number) {
    this.store.dispatch(addButtonData({ section, name, value }));
  }
}
