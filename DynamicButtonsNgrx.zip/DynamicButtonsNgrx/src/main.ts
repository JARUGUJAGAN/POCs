import { bootstrapApplication } from '@angular/platform-browser';
import { provideStore } from '@ngrx/store';
import { sectionReducer } from './app/store/section.reducer'; // Import the sectionReducer
import { AppComponent } from './app/app.component'; // Import your standalone app component

bootstrapApplication(AppComponent, {
  providers: [
    provideStore({ section: sectionReducer }), // Set up NgRx store
  ],
}).catch((err) => console.error(err));
