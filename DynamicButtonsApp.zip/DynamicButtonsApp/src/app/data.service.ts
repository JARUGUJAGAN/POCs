
// src/app/data.service.ts
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class DataService {
  // private sectionSubject = new BehaviorSubject<string | null>(null);
 // Subject to emit button data
 private buttonClickSubject = new BehaviorSubject<{ section: string; name: string; value: number } | null>(null);

 // Observable for parent component to listen to button clicks
 buttonClick$ = this.buttonClickSubject.asObservable();
  // getCurrentSection: any;

 // Track sections data and total value
 private sectionDataSubject = new BehaviorSubject<{ [key: string]: { name: string; value: number }|null }>({});
 sectionData$ = this.sectionDataSubject.asObservable();

 private totalValueSubject = new BehaviorSubject<number>(0);
 totalValue$ = this.totalValueSubject.asObservable();
   // Emit button click event
   emitButtonClick(section: string, name: string, value: number) {
    this.buttonClickSubject.next({ section, name, value }); // Emit the button click data
  }
  constructor() {
    // On initialization, load the saved section from localStorage
    const savedSection = localStorage.getItem('selectedSection');
    if (savedSection) {
      this.currentSectionSubject.next(savedSection);
    }
  }
    // Subject to track the currently selected section
    private currentSectionSubject = new BehaviorSubject<string | null>(null);
    currentSection$ = this.currentSectionSubject.asObservable();

    // Set the currently selected section
  setCurrentSection(section: string) {
    this.currentSectionSubject.next(section);
  }

  // Get the currently selected section
  getCurrentSection(): string | null {
    return this.currentSectionSubject.value?? '';
  }

  setSection(section: string) {
    this.currentSectionSubject.next(section);
    localStorage.setItem('selectedSection', section);
    
  }

  getSection(): Observable<string | null> {
    return this.currentSectionSubject.asObservable();
  }

  getButtonsForSection(section: string): { name: string; value: number }[] {
    const buttonData: { [key: string]: { name: string; value: number }[] } = {
      "1": [
        { name: '#fgg', value: 2 },
        { name: ' $779', value: 6 }, { name: ' !898989', value: 66 },
        { name: ' &bjbbj', value: 223 },
      ],
      "2": [
        { name: ' ERT66', value: 7 },
        { name: ' @ggugj', value: 3 }, { name: ' !898989', value: 66 },
        { name: ' &bjbbj', value: 223 },
      ],
      "3": [
        { name: ' @55', value: 88 },
        { name: ' !jbjbj', value: 69 },
        { name: ' ERT66', value: 7 },
        { name: ' @ggugj', value: 3 },
      ],
      "4": [
        { name: ' Goooo', value: 99 },
        { name: ' LULUL', value: 77 },{ name: ' &&&777', value: 66 },
        { name: ' 876476', value: 223 },
      ],
      "5": [
        { name: ' *gyfyf', value: 90 },
        { name: ' ^&**#', value: 889 },{ name: ' ERT66', value: 7 },
        { name: ' @ggugj', value: 3 },
      ],
      "6": [
        { name: ' !898989', value: 66 },
        { name: ' &bjbbj', value: 223 }, { name: ' &&&777', value: 66 },
        { name: ' 876476', value: 223 },
      ],
      "7": [
        { name: ' !78797', value: 66 },
        { name: ' ((777(', value: 223 },{ name: ' !898989', value: 66 },
        { name: ' &bjbbj', value: 223 },
      ],
      "8": [
        { name: ' )(*&^%', value: 66 },
        { name: ' )(@@!', value: 223 },{ name: ' !898989', value: 66 },
        { name: ' &bjbbj', value: 223 },
      ],
      "9": [
        { name: ' &&&777', value: 66 },
        { name: ' 876476', value: 223 }, { name: ' @55', value: 88 },
        { name: ' !jbjbj', value: 69 },
        { name: ' ERT66', value: 7 },
        { name: ' @ggugj', value: 3 },
      ],"10": [
        { name: ' ^^^^^^', value: 66 },
        { name: ' *(*&^*', value: 223 }, { name: ' &&&777', value: 66 },
        { name: ' 876476', value: 223 },
      ]
      // Add more sections as needed
    };
    return buttonData[section] || [];
  }

  resetSections() {
    this.sectionDataSubject.next({}); // Clear all section data
    this.totalValueSubject.next(0); // Reset the total value to 0
    localStorage.removeItem('selectedSection'); // Optionally clear the selected section from localStorage
  }
 // Ensure only one item per section
 updateSectionData(section: string, name: string, value: number) {
  const currentData = this.sectionDataSubject.value;
  currentData[section] = { name, value }; // Replace the current data with the new one for the section

  this.sectionDataSubject.next(currentData);

  // Recalculate the total value by summing values of all sections
  let total = 0;
  Object.values(currentData).forEach((data) => {
    if (data) {
      total += data.value;
    }
  });

  this.totalValueSubject.next(total);
}
}
