


import { Component, ChangeDetectionStrategy, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { CommonModule } from '@angular/common';
import { ChildComponent } from '../child/child.component';

@Component({
  selector: 'app-parent',
  standalone: true,
  imports: [CommonModule, ChildComponent], // Ensure ChildComponent is imported here
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ParentComponent implements OnInit {
  sections = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10'];
  selectedSection: string | null = null;
  sectionData: { [key: string]: { name: string; value: number }|null } = {};
  totalValue = 0;
  isChildVisible = false;
  constructor(private dataService: DataService) {}

  selectSection(section: string) {
    this.selectedSection = section;
    this.dataService.setSection(section);
     this.isChildVisible = true;
  }

  ngOnInit() {
    this.dataService.currentSection$.subscribe((section) => {
      if (section) {
        this.selectedSection = section;
        this.isChildVisible = true;
      }else {
        this.isChildVisible = false; // Hide child when no section is selected
      }
    });

    this.dataService.buttonClick$.subscribe((buttonData) => {
      // debugger
      // console.log(buttonData)
      if (buttonData ) {
        const { section, name, value } = buttonData;
        this.dataService.updateSectionData(section, name, value);
        
       
      }
    });
    this.dataService.sectionData$.subscribe((sectionData) => {
      this.sectionData = sectionData;
    });

    this.dataService.totalValue$.subscribe((total) => {
      this.totalValue = total;
    });

    // Subscribe to button clicks to update section data
    this.dataService.buttonClick$.subscribe((buttonData) => {
      if (buttonData) {
        const { section, name, value } = buttonData;
        this.dataService.updateSectionData(section, name, value); // Update section data
      }
    });
  }
  reset() {
    this.dataService.resetSections(); // Reset all sections and total value
    this.selectedSection = null;
    this.isChildVisible = false;
  }
}
