

// src/app/child/child.component.ts
import { Component, OnInit, ChangeDetectionStrategy,Input } from '@angular/core';
import { DataService } from '../data.service';
import { Observable } from 'rxjs';
import { CommonModule } from '@angular/common';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-child',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './child.component.html',
  styleUrl:'./child.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ChildComponent implements OnInit {
  buttons$!: Observable<{ name: string; value: number; }[]>;
  @Input() section!: string;
  constructor(private dataService: DataService) {}

  ngOnInit() {
    this.buttons$ = this.dataService.getSection().pipe(
      map((section) => (section ? this.dataService.getButtonsForSection(section) : []))
    );
  }
  
  onButtonClick(button: { name: string; value: number }) {
    // Emit button click with the currently selected section
    // debugger
    this.dataService.emitButtonClick(this.dataService.getCurrentSection()!, button.name, button.value);
// console.log(button) 
 }
}
